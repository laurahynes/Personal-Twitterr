#include <ctype.h>          //used in countStopWords and searchTweetsByKeyword
#include <stdbool.h>        //used in searchTweetsByKeyword